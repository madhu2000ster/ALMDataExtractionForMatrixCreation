﻿
UserName = "mbaital" '"mbaital" 
Password = "Welcome2ibm1!" 
'''''''''''''''''''''''''''QCConnection'''''''''''''''''''''''''''''''''''''
dim QCConnection 
Set QCConnection = CreateObject("TDApiOle80.TDConnection")
QCConnection.InitConnectionEx "https://hpalm-qc.bmogc.net:8443/qcbin/"
QCConnection.login UserName, Password

Domain = DataTable.Value("Domain")
Project = DataTable.Value("Project")
QCConnection.Connect Domain, Project
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''  
'WScript.Sleep 5000
wait(2)
    
' Get the bug factory filter. 
  Set BugFact = QCConnection.BugFactory
  Set BugFilter = BugFact.Filter
    

Set XL = CreateObject("Excel.Application")
Set filesys = CreateObject("Scripting.FileSystemObject")
'Make the Excel visible (use False to have it run invisible).
'XL.Visible = True
Wait(1)
' Open the IP address workbook
Set oWb = XL.Workbooks.Open("C:\BMO\01 MetricesDashboard\ALMDataExtraction.xlsx")
AllProject =  split(DataTable.Value("ProjectName"),"|")
AllSeverity = Split(DataTable.Value("Severity"),"|")

'For Iterator1 = 0 To Ubound(AllProject)
'	BugFilter.Filter("BG_PROJECT") = AllProject(Iterator1)
	
	For Iterator2 = 0 To Ubound(AllSeverity)
	    	BugFilter.Filter("BG_SEVERITY") = AllSeverity(Iterator2)
	
	    	'BugFilter.Filter("BG_PROJECT") = Datatable.Value("ProjectName")
	    	BugFilter.order("BG_SEVERITY") = 1
	    	Set bugList = BugFilter.NewList
	    	DefectDetectedInUAT = 0
	    	For each objBug in bugList
	    		strSummary = objBug.Field("BG_SUMMARY")
	    		If mid(strSummary,1,3) =  "UAT" Then
	    			DefectDetectedInUAT = DefectDetectedInUAT + 1
	     		End If
	     		
	    	Next
	   	
			rowCount = oWb.Sheets("DefectLeakage").UsedRange.Rows.Count
		'Add a value to the A column on the next blank row
		oWb.Sheets("DefectLeakage").Cells((rowCount+1),("A")).Value = day(date)&"-"&monthname(month(Date),true)&"-"&year(date)
		oWb.Sheets("DefectLeakage").Cells((rowCount+1),("B")).Value = Project
		oWb.Sheets("DefectLeakage").Cells((rowCount+1),("C")).Value = BugFilter.Filter("BG_PROJECT")
		oWb.Sheets("DefectLeakage").Cells((rowCount+1),("D")).Value = bugList.Count
		oWb.Sheets("DefectLeakage").Cells((rowCount+1),("E")).Value = DefectDetectedInUAT
		oWb.Sheets("DefectLeakage").Cells((rowCount+1),("F")).Value = BugFilter.Filter("BG_SEVERITY")
		
	Next
'NEXT
  
 oWb.Save
 oWb.Close

