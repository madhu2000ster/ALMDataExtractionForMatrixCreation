﻿	Dim QCConnection
	
	UserName = "rdas06" 'InputBox("Enter the user name for QC Login", "QC UserName")
	Password = "Bumba@1212" 'InputBox("Enter the password for QC Login", "QC Password")

	Set QCConnection= CreateObject("TDApiOle80.TDConnection")
	QCConnection.InitConnectionEx "https://hpalm-qc.bmogc.net:8443/qcbin/"
	QCConnection.Login UserName, Password
	Wait(4)
	Dim arrExeDate()
	For Iterator = 1 To DataTable.GlobalSheet.GetRowCount
		Domain =  DataTable.GlobalSheet.GetParameter("Domain").Value
		Project = DataTable.GlobalSheet.GetParameter("Project").Value
		TestSetFolderPath = DataTable.GlobalSheet.GetParameter("NodePath").Value
		TestSetName = DataTable.GlobalSheet.GetParameter("TestSetName").Value
		QCConnection.Connect Domain, Project 
		
		Set TSetFact = QCConnection.TestSetFactory
        Set tsTreeMgr = QCConnection.TestSetTreeManager
		Set tsFolder = tsTreeMgr.NodeByPath(TestSetFolderPath)
		Set tsList = tsFolder.FindTestSets(TestSetName)
		Set theTestSet = tsList.Item(1)
		
		Set XL = CreateObject("Excel.Application")
		Set filesys = CreateObject("Scripting.FileSystemObject")
		Wait(1)
		Set oWb = XL.Workbooks.Open("C:\BMO\01 MetricesDashboard\ALMDataExtraction.xlsx")
		RunCount = 0
		TotNoOfExeDate= 0
		TestExecutionProductivity= 0
		i = 0
		
			
    	''''''''''''''''''''''''''	ActualRunCount '''''''''''''''''''''''''''''''''''
		For Testset_Count = 1 To tsList.Count
			Set TestSetFilter = TSetFact.Filter
			Set Testfactory = QCConnection.TestFactory
			Set TestFilter = Testfactory.Filter
			If TestSetName <> "" Then
				TestSetFilter.Filter("CY_CYCLE") =  Chr(34) & TestSetName & Chr(34)
			End If
			Set TestList = TSetFact.NewList(TestSetFilter.Text)
			TestFilter.SetXFilter "TEST-TESTSET", True, testSetFilter.Text
			Set TestList = Testfactory.NewList(TestFilter.Text)
			For Each Test In TestList
				'msgbox Test.Name
				'msgbox Date()
				If (Not (Test.LastRun Is Nothing)) Then
					ActualExecutionDate =  FormatDateTime(Test.ExecDate,2)
					Select Case Weekday(ActualExecutionDate)
        				Case vbSaturday, vbSunday
            					IsWeekend = True
        				Case Else
           					 	IsWeekend = False
    				End Select
    				If IsWeekend = False Then
    					ReDim preserve arrExeDate(i) 
						arrExeDate(i) = ActualExecutionDate
						i = i+1
						RunCount = RunCount+1
    				End If
				End If
			Next
			Dim dateMin, dateMax
 			dateMin = arrExeDate(0)
    		dateMax = arrExeDate(0)
			Dim j
    		For j=1 to UBound(arrExeDate)
        		If cdate(arrExeDate(j)) < cdate(dateMin) Then 
        			dateMin = arrExeDate(j)
        		End If	
        		if cdate(arrExeDate(j)) > cdate(dateMax) Then 
        			dateMax = arrExeDate(j)
        		End If
    		Next 
			TotNoOfExeDate = (cDate(dateMax) - cDate(dateMin))+1
			If TotNoOfExeDate <> 0 Then
				TestExecutionProductivity = RunCount/TotNoOfExeDate
			End If
			
			rowCount = oWb.Sheets("TestExecutionProductivity").Range("A1").CurrentRegion.Rows.Count
			
			oWb.Sheets("TestExecutionProductivity").Cells((rowCount+1),("A")).Value = Date()
			oWb.Sheets("TestExecutionProductivity").Cells((rowCount+1),("B")).Value = Project
	        oWb.Sheets("TestExecutionProductivity").Cells((rowCount+1),("C")).Value = TestSetFolderPath
	        oWb.Sheets("TestExecutionProductivity").Cells((rowCount+1),("D")).Value = TestSetName
			oWb.Sheets("TestExecutionProductivity").Cells((rowCount+1),("E")).Value = TotNoOfExeDate
			oWb.Sheets("TestExecutionProductivity").Cells((rowCount+1),("F")).Value = RunCount
			oWb.Sheets("TestExecutionProductivity").Cells((rowCount+1),("G")).Value = TestExecutionProductivity
			

		Next
		oWb.Save
		oWb.Close
		Set oWb = Nothing	
		DataTable.GlobalSheet.SetNextRow
	Next
	
	





















