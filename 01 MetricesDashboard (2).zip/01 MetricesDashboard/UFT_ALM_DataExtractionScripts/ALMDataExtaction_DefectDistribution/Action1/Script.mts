﻿
UserName = "rdas06" 
Password = "Nov@2018" 
'''''''''''''''''''''''''''QCConnection'''''''''''''''''''''''''''''''''''''
dim QCConnection 
Set QCConnection = CreateObject("TDApiOle80.TDConnection")
QCConnection.InitConnectionEx "https://hpalm-qc.bmogc.net:8443/qcbin/"
QCConnection.login UserName, Password


'For Iterator = 1 To DataTable.GlobalSheet.GetRowCount	
	
	Domain = DataTable.Value("Domain")
	Project = DataTable.Value("Project")
	QCConnection.Connect Domain, Project
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''  
	'WScript.Sleep 5000
	wait(2)
	    
	' Get the bug factory filter. 
	  Set BugFact = QCConnection.BugFactory
	  Set BugFilter = BugFact.Filter
	    
	AllStatus =  split(DataTable.Value("Status"),"|")
	AllSeverity = Split(DataTable.Value("Severity"),"|") 
	AllProject =  Split(DataTable.Value("ProjectName"),"|")
	
	Set XL = CreateObject("Excel.Application")
	Set filesys = CreateObject("Scripting.FileSystemObject")
	'Make the Excel visible (use False to have it run invisible).
	'XL.Visible = True
	Wait(1)
	' Open the IP address workbook
	Set oWb = XL.Workbooks.Open("C:\BMO\01 MetricesDashboard\ALMDataExtraction.xlsx")
	
	For Iterator1 = 0 To Ubound(AllStatus)
		BugFilter.Filter("BG_STATUS") = AllStatus(Iterator1)
		For Iterator2 = 0 To Ubound(AllSeverity)
	    	BugFilter.Filter("BG_SEVERITY") = AllSeverity(Iterator2)
	    	'BugFilter.order("BG_PROJECT") = 1
	    	
		    	For Iterator3 = 0 To Ubound(AllProject)
		    		BugFilter.Filter("BG_USER_01") = AllProject(Iterator3)
		    		ProjectCode=BugFilter.Filter("BG_USER_01")
		    		BugFilter.order("BG_USER_01") = 1
		    	 	Set bugList = BugFilter.NewList
		    	
		    	If bugList.Count>0 Then
	    			    	
				rowCount = oWb.Sheets("DefectDistribution").UsedRange.Rows.Count

			
						'Add a value to the A column on the next blank row
						oWb.Sheets("DefectDistribution").Cells((rowCount+1),("A")).Value = day(date)&"-"&monthname(month(Date),true)&"-"&year(date)
						oWb.Sheets("DefectDistribution").Cells((rowCount+1),("B")).Value = Project
						oWb.Sheets("DefectDistribution").Cells((rowCount+1),("C")).Value = ProjectCode
						oWb.Sheets("DefectDistribution").Cells((rowCount+1),("F")).Value = bugList.Count
						oWb.Sheets("DefectDistribution").Cells((rowCount+1),("D")).Value = BugFilter.Filter("BG_SEVERITY")
						oWb.Sheets("DefectDistribution").Cells((rowCount+1),("E")).Value = BugFilter.Filter("BG_STATUS") 
				End If
				
			
		Next
		Next
	 Next 
	 
	 oWb.Save
	 oWb.Close
	 
'Next
Set XL = nothing
