﻿	Dim QCConnection
	
	UserName = "rdas06" 'InputBox("Enter the user name for QC Login", "QC UserName")
	Password = "Bumba@1212" 'InputBox("Enter the password for QC Login", "QC Password")

	Set QCConnection= CreateObject("TDApiOle80.TDConnection")
	QCConnection.InitConnectionEx "https://hpalm-qc.bmogc.net:8443/qcbin/"
	QCConnection.Login UserName, Password
	Wait(4)
	For Iterator = 1 To DataTable.GlobalSheet.GetRowCount
		Domain =  DataTable.GlobalSheet.GetParameter("Domain").Value
		Project = DataTable.GlobalSheet.GetParameter("Project").Value
		TestSetFolderPath = DataTable.GlobalSheet.GetParameter("NodePath").Value
		TestSetName = DataTable.GlobalSheet.GetParameter("TestSetName").Value
		QCConnection.Connect Domain, Project 
		
		Set TSetFact = QCConnection.TestSetFactory
        Set tsTreeMgr = QCConnection.TestSetTreeManager
		Set tsFolder = tsTreeMgr.NodeByPath(TestSetFolderPath)
		Set tsList = tsFolder.FindTestSets(TestSetName)
		Set theTestSet = tsList.Item(1)
		
		Set XL = CreateObject("Excel.Application")
		Set filesys = CreateObject("Scripting.FileSystemObject")
		'Make the Excel visible (use False to have it run invisible).
		'XL.Visible = True
		Wait(1)
		' Open the IP address workbook
		Set oWb = XL.Workbooks.Open("C:\BMO\01 MetricesDashboard\ALMDataExtraction.xlsx")
		
		PlannedCountByWeek = 0  
		ActualCountByWeek = 0
        For Iterator1 = 6 To 1 step -1
        	PlannnedExecutionCount = 0
    		ActualRunCount = 0
    		
    		''''''''''''''''''''''''''	ActualRunCount '''''''''''''''''''''''''''''''''''
			For Testset_Count = 1 To tsList.Count
				Set TestSetFilter = TSetFact.Filter
				Set Testfactory = QCConnection.TestFactory
				Set TestFilter = Testfactory.Filter
				If TestSetName <> "" Then
					TestSetFilter.Filter("CY_CYCLE") =  Chr(34) & TestSetName & Chr(34)
				End If
				Set TestList = TSetFact.NewList(TestSetFilter.Text)
				TestFilter.SetXFilter "TEST-TESTSET", True, testSetFilter.Text
				Set TestList = Testfactory.NewList(TestFilter.Text)
		    		For Each Test In TestList
						'msgbox Test.Name
						If (Not (Test.LastRun Is Nothing)) Then
							ActualExecutionDate =  Test.ExecDate
							If ActualExecutionDate = Date()- Iterator1 Then
									ActualRunCount = ActualRunCount+1
								End IF
						End If
					Next
			Next
			
		''''''''''''''''''''''''''	PlannnedExecutionCount '''''''''''''''''''''''''''''''''''
			
		For Testset_Count = 1 To tsList.Count

			Set theTestSet = tsList.Item(Testset_Count)
    		Set TSTestFact = theTestSet.TSTestFactory
    		Set TestSetTestsList = TSTestFact.NewList("")
    		For Each theTSTest In TestSetTestsList
				
					If (Not (theTSTest.LastRun Is Nothing)) Then
						Set TSTestExec = theTSTest.ExecutionSettings
						PlannedExecutionDate =  TSTestExec.PlannedExecutionDate
						If PlannedExecutionDate = Date()- Iterator1 Then
							PlannnedExecutionCount = PlannnedExecutionCount+1
						End IF				
					End IF
				Next
				
					rowCount = oWb.Sheets("TestExecutionPlannedVsActual").UsedRange.Rows.Count
					'Add a value to the A column on the next blank row
					oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("A")).Value = Date() - Iterator1
					If Project = "PR018074_NetReveal_7_4_Upgrade" Then
						oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("B")).Value = Project
					End If
					
					oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("C")).Value = TestSetFolderPath
					oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("D")).Value = TestSetName
					oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("E")).Value = ActualRunCount
					oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("F")).Value = PlannnedExecutionCount
					
'					DataTable.Value("Date",dtLocalsheet) = Date() - Iterator1
'					DataTable.Value("ActualCount",dtLocalsheet) = ActualRunCount
'					DataTable.Value("PlannedCount",dtLocalsheet) = PlannnedExecutionCount
'					DataTable.LocalSheet.SetCurrentRow(DataTable.LocalSheet.GetCurrentRow+1)
					PlannedCountByWeek = PlannedCountByWeek + PlannnedExecutionCount  
					ActualCountByWeek = ActualCountByWeek+ ActualRunCount
					
					If Iterator1=1 Then
					
						oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("H")).Value = ActualCountByWeek
						oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("G")).Value = PlannedCountByWeek
						oWb.Sheets("TestExecutionPlannedVsActual").Cells((rowCount+1),("I")).Value = PlannedCountByWeek-ActualCountByWeek
						
					End If
			Next
		Next
	Next
	
	
 oWb.Save
 oWb.Close
 
' Set XL = CreateObject("Excel.Application")
'		Set filesys = CreateObject("Scripting.FileSystemObject")
'		'Make the Excel visible (use False to have it run invisible).
'		'XL.Visible = True
'		Wait(1)
'		' Open the IP address workbook
'		Set oWb = XL.Workbooks.Open("C:\BMO\01 MetricesDashboard\Defect.xlsx")
'		WHAT_TO_FIND = "Actimize"
''Dim ws As Excel.Worksheet
''Dim FoundCell As Excel.Range
''
''Set ws = ActiveSheet
'Set FoundCell = oWb.Sheets("Summary").Range("A:A").Find(WHAT_TO_FIND)
'If Not FoundCell Is Nothing Then
'    MsgBox (WHAT_TO_FIND & " found in row: " & FoundCell.Row)
'Else
'    MsgBox (WHAT_TO_FIND & " not found")
'End If
'	
' oWb.Save
' oWb.Close
'
