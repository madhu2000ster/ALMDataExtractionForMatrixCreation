﻿	Dim QCConnection
	
	UserName = "rdas06" 'InputBox("Enter the user name for QC Login", "QC UserName")
	Password = "Bumba@1212" 'InputBox("Enter the password for QC Login", "QC Password")

	Set QCConnection= CreateObject("TDApiOle80.TDConnection")
	QCConnection.InitConnectionEx "https://hpalm-qc.bmogc.net:8443/qcbin/"
	QCConnection.Login UserName, Password
	For Iterator = 1 To DataTable.GlobalSheet.GetRowCount
		Domain =  DataTable.GlobalSheet.GetParameter("Domain").Value
		Project = DataTable.GlobalSheet.GetParameter("Project").Value
		TestSetFolderPath = DataTable.GlobalSheet.GetParameter("NodePath").Value
		TestSetName = DataTable.GlobalSheet.GetParameter("TestSetName").Value
		AllStatus = DataTable.GlobalSheet.GetParameter("AllStatus").Value
		
		Status = Split(AllStatus,"|")
		'msgbox Status(0)
		QCConnection.Connect Domain, Project 
		Wait(5)
		setFilter = TestSetName
		
		Set TSetFact = QCConnection.TestSetFactory
        Set tsTreeMgr = QCConnection.TestSetTreeManager
		Set tsFolder = tsTreeMgr.NodeByPath(TestSetFolderPath)
		Set tsList = tsFolder.FindTestSets(TestSetName)
		Set theTestSet = tsList.Item(1)
		

		Set XL = CreateObject("Excel.Application")
		Set filesys = CreateObject("Scripting.FileSystemObject")
		Wait(1)
		Set oWb = XL.Workbooks.Open("C:\BMO\01 MetricesDashboard\ALMDataExtraction.xlsx")
		
		
		For Testset_Count = 1 To tsList.Count
			Set TestSetFilter = TSetFact.Filter
			Set Testfactory = QCConnection.TestFactory
			Set TestFilter = Testfactory.Filter
			If TestSetName <> "" Then
				TestSetFilter.Filter("CY_CYCLE") =  Chr(34) & TestSetName & Chr(34)
			End If
			Set TestList = TSetFact.NewList(TestSetFilter.Text)
			TestFilter.SetXFilter "TEST-TESTSET", True, testSetFilter.Text
			Set TestList = Testfactory.NewList(TestFilter.Text)
			
				For Each Test In testList
					If (Test.LastRun Is Nothing) Then
						noRunCount =noRunCount+1 
					ElseIf (Not (Test.LastRun Is Nothing)) Then
						If (Test.LastRun.Status = "Passed") Then
							passCount = passCount+1
						ElseIf (Test.LastRun.Status = "Failed") Then
							failCount=failCount+1	
						ElseIf (Test.LastRun.Status = "Not Completed") Then
							notCompletedCount=notCompletedCount+1					
						End If
					End If
				Next
				For Iterator1 = 0 To Ubound(Status)
					rowCount = oWb.Sheets("TestProgression").Range("A1").CurrentRegion.Rows.Count
					oWb.Sheets("TestProgression").Cells((rowCount+1),("A")).Value = Date()
					oWb.Sheets("TestProgression").Cells((rowCount+1),("B")).Value = Project
        			oWb.Sheets("TestProgression").Cells((rowCount+1),("C")).Value = TestSetFolderPath
        			oWb.Sheets("TestProgression").Cells((rowCount+1),("D")).Value = TestSetName
        			If Status(Iterator1) = "Passed" Then
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("E")).Value = Status(Iterator1)
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("F")).Value = passCount
        			ElseIf Status(Iterator1) = "Failed" Then	
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("E")).Value = Status(Iterator1)
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("F")).Value = failCount
        			ElseIf Status(Iterator1) ="Not Completed" Then	
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("E")).Value = Status(Iterator1)
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("F")).Value = notCompletedCount
        			ElseIf Status(Iterator1) ="No Run" Then	
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("E")).Value = Status(Iterator1)
        				oWb.Sheets("TestProgression").Cells((rowCount+1),("F")).Value = noRunCount	
        			End If
				Next
		Next
		oWb.Save
 		oWb.Close
Next

