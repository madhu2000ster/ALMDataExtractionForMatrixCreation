Dim QTPObj,QTPTest
Set QTPObj=CreateObject("QuickTest.Application")

'Check if the application is not already Launched
If Not QTPObj.Launched then
QTPObj.Launch
end if

QTPObj.Visible=True

QTPObj.Open "C:\BMO\01 MetricesDashboard\UFT_ALM_DataExtractionScripts\ALMDataExtaction_DefectDistribution" 'name of the start up script
Set QTPTest=QTPObj.Test
QTPTest.Run 'Run the Test
QTPTest.Close 'Close the Test

QTPObj.Open "C:\BMO\01 MetricesDashboard\UFT_ALM_DataExtractionScripts\ALMDataExtaction_DefectLeakage" 'name of the start up script
Set QTPTest=QTPObj.Test
QTPTest.Run 'Run the Test
QTPTest.Close 'Close the Test

QTPObj.Open "C:\BMO\01 MetricesDashboard\UFT_ALM_DataExtractionScripts\ALMDataExtraction_ExecutionPlannedVsActual" 'name of the start up script
Set QTPTest=QTPObj.Test
QTPTest.Run 'Run the Test
QTPTest.Close 'Close the Test

QTPObj.Open "C:\BMO\01 MetricesDashboard\UFT_ALM_DataExtractionScripts\ALMDataExtraction_ExecutionProductivity" 'name of the start up script
Set QTPTest=QTPObj.Test
QTPTest.Run 'Run the Test
QTPTest.Close 'Close the Test

QTPObj.Open "C:\BMO\01 MetricesDashboard\UFT_ALM_DataExtractionScripts\ALMDataExtraction_ExecutionProgress" 'name of the start up script
Set QTPTest=QTPObj.Test
QTPTest.Run 'Run the Test
QTPTest.Close 'Close the Test


QTPObj.Quit 'Quit the QTP Application
